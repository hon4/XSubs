<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

stdhead("Subtitles");
begin_frame("Subtitles");
?>
<div class="searchbox"><form method="get" action="subtitles.php" style="text-align:right">
	<input type="text" name="search" style="width:100%" value="<?=$_GET['search']?>">
	<input type="submit" value="Search">
</form></div>
<?php
if($_GET['search'])
	$wherea[]="name LIKE ".sqlesc("%$_GET[search]%");


if($_GET['user']){
	$res=sql_query("SELECT id FROM users WHERE username=".sqlesc($_GET['user']));
	$row=mysql_fetch_assoc($res);
	$_GET['userid']=$row['id'];
	unset($_GET['user']);
}

if($_GET['userid'])
	$wherea[]="owner=".sqlesc($_GET['userid']);

$where=($wherea?" WHERE ".implode(" AND ",$wherea):"");

//GET NUMBER FOUND FOR PAGER
$res=sql_query("SELECT COUNT(*) FROM subtitles$where");
$row=mysql_fetch_array($res);
$count=$row[0];
$uri="subtitles.php?";
$i=0;
$gk=array_keys($_GET);
foreach($_GET as $p){
	if($gk[$i]!="page")
		$uri.="$gk[$i]=$p&";
	$i++;
}

if($count){
	list($pagertop,$pagerbottom,$limit)=pager(20,$count,$uri);
	$res=sql_query("SELECT * FROM subtitles$where ORDER BY id DESC $limit");
	print($pagertop);
	subtitletable($res);
	print($pagerbottom);
}else{
	echo "No uploaded subtitles.";
}
end_frame();
stdfoot();
?>