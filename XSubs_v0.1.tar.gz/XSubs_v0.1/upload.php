<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

loggedinonly();

stdhead("Upload");

if($_POST['takeupload']){
	if(!$_POST['lang']||!is_numeric($_POST['lang'])){
		stderr("No language selected.");
	}else{
		if($_FILES["subtitle"]["name"]){
			$subname=$_FILES["subtitle"]["name"];
			$name=$_POST['name'];
			if(!$name)
				$name=substr($subname,0,strrpos($subname,'.')); 
			$sub=file_get_contents($_FILES["subtitle"]["tmp_name"]);
			$sub=gzencode($sub,9);
			$res=sql_query("INSERT INTO subtitles (name,filename,owner,descr,added,lang) VALUES (".sqlesc($name).",".sqlesc($subname).",'".$CURUSER['id']."',".sqlesc($_POST['descr']).",".sqlesc(get_datetime()).",".sqlesc($_POST['lang']).")");
			$id=mysql_insert_id();
			file_put_contents("subs/$id.gz",$sub);
			header("Location: details.php?id=$id");
		}else{
			stderr("No subtitle file selected.");
		}
	}
}

$lng=langlist();
$langdrop="";
foreach($lng as $l){
	$langdrop.="<option value='$l[i]'>$l[n]</option>";
}
?>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="takeupload" value="1">
<table class="coltable" align="center">
<tr><td class="rowhead" width="1">Uploading as</td><td class="row1"><b><font color="gold"><?=$CURUSER['username']?></font></b></td></tr>
<tr><td class="rowhead" width="1"><nobr>Subtitle Name</nobr></td><td class="row1"><input type="text" name="name" size="34"/></td></tr>
<tr><td class="rowhead" width="1">Subtitle</td><td class="row1"><input type="file" name="subtitle"/></td></tr>
<tr><td class="rowhead">Language</td><td class="row1"><select name="lang"><?=$langdrop?></select></td></tr>
<tr><td class="rowhead">Description</td><td class="row1"><textarea name="descr" cols="33" rows="5"></textarea></td></tr>
<tr><td colspan='2' class='colhead' align='center'><input type="submit" value="Upload (PRESS ONLY ONCE)"/></td></tr>
</table>
</form>
<?php
stdfoot();
?>