<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

stdhead("Recover");

if($_SERVER["REQUEST_METHOD"]=="POST"){
	$email=trim($_POST['email']);
	if(!$email){
		stderr("You must enter an email address.");
	}else{
		$res=sql_query("SELECT id FROM users WHERE email=".sqlesc($_POST['email']));
		if(!mysql_num_rows($res)){
			stderr("The email address was not found in our database.");
		}else{
			$row=mysql_fetch_assoc($res);
			$sec=mksecret();
			sql_query("UPDATE users SET editsecret=".sqlesc($sec)." WHERE id=".$row["id"]);
			if(!mysql_affected_rows()){
				stderr("Database error. Please contact an administrator about this.");
				stdfoot();
				die();
			}
			$psecret=md5($sec);
			$body=<<<EOD
Someone, hopefully you, requested that the password for the account
associated with this email address ($email) be reset.

The request originated from {$_SERVER["REMOTE_ADDR"]}.

If you did not do this ignore this email. Please do not reply.


Should you wish to confirm this request, please follow this link:

$CONF[SITEURL]/recover.php?id={$row["id"]}&secret=$psecret


After you do this, your password will be reset and emailed back
to you.

--
$CONF[SITENAME]
EOD;

			@mail($_POST['email'],"$CONF[SITENAME] password reset confirmation",$body,"From: $CONF[SITEEMAIL]","-f$CONF[SITEEMAIL]") or stderr("Unable to send mail. Please contact an administrator about this error.");
			stderr("A confirmation email has been mailed. Please allow a few minutes for the mail to arrive.","Success");
			stdfoot();
			die();
		}
	}
}elseif($_GET){
	if(!$_GET['id']||!$_GET['secret']){
		stderr("Missing data.");
	}else{
		$res=sql_query("SELECT id,username,email,editsecret FROM users WHERE id=".sqlesc($_GET['id']));
		if(!$res){
			stderr("Bad ID.");
		}else{
			$row=mysql_fetch_assoc($res);
			if(md5($row['editsecret'])===$_GET['secret']){
				$password=mksecret();
				sql_query("UPDATE users SET password='".md5($password)."',editsecret=NULL WHERE id='$row[id]'");
				if(!mysql_affected_rows())
					stderr("Unable to update user data. Please contact an administrator about this error.");
				$body=<<<EOD
As per your request we have generated a new password for your account.

Here is the information we now have on file for this account:

    User name: {$row["username"]}
    Password:  $password

You may login at $CONF[SITEURL]/login.php

--
$CONF[SITENAME]
EOD;
				@mail($row['email'],"$CONF[SITENAME] account details",$body,"From: $CONF[SITEEMAIL]","-f$CONF[SITEEMAIL]") or stderr("Unable to send mail. Please contact an administrator about this error.");
				stderr("The new account details have been mailed to <b>$row[email]</b><br/>Please allow a few minutes for the mail to arrive.","Success");
			}else{
				stderr("Bad secret.");
			}
		}
	}
}else{
	stderr("Use the form below to have your password reset and your account details mailed back to you.<br/>
	  (You will have to reply to a confirmation email.)","Recover lost user name or password");
	?>
	<form method="post">
		<table class="coltable" align="center">
			<tr><td class="rowhead">Registered email</td><td class="row1"><input type="text" name="email" size="30"/></td></tr>
			<tr><td colspan="2" class="colhead" align="center"><input type="submit" value="Do it!"/></td></tr>
		</table>
	</form>
	<?php
}
stdfoot();
?>