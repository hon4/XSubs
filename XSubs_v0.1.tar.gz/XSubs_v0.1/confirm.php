<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();


if(!$_GET['id']||!$_GET['secret']||strlen($_GET['secret'])!=32){
	die("Missing data");
}else{
	$res=sql_query("SELECT id,secret FROM users WHERE status='pending' AND id=".sqlesc($_GET['id']));
	if(!$res){
		stderr("User not found. Try to sign up again.");
	}else{
		$row=mysql_fetch_assoc($res);
		if(md5($row['secret'])===$_GET['secret']){
			sql_query("UPDATE users SET status='confirmed' WHERE id=".sqlesc($row['id']));
			if(mysql_affected_rows()!=1){
				die("Unable to update user.");
			}else{
				stdhead();
				stderr("Your account has been successfully cronfirmed.<br/>Click <a href='login.php'>here</a> to login.","Success");
				stdfoot();
			}
		}else{
			die("Bad secret.");
		}
	}
}
?>