<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

logoutcookie();

stdhead("Login");

if($_POST['takelogin']){
	if(!$_POST['username']||!$_POST['password']){
		stderr("No username or password.");
	}else{
		$res=sql_query("SELECT id,password,secret,status FROM users WHERE username=".sqlesc($_POST['username']));
		if(!$res){
			stderr("Bad username or password.");
		}else{
			$row=mysql_fetch_assoc($res);
			$password=md5($_POST['password']);
			if($row['password']===$password){
				if($row['status']!="confirmed"){
					stderr("Your account is not confirmed. Please check your email.");
				}else{
					logincookie($row['id'],$password,$row['secret']);
					if($_POST['returnto']){
						header("Location: ".$_POST['returnto']);
					}else{
						header("Location: index.php");
					}
				}
			}else{
				stderr("Bad username or password.");
			}
		}
	}
}
?>
<form method="post">
	<table class="coltable" align="center">
		<input type="hidden" name="takelogin" value="1"/>
		<tr><td width="1" class="rowhead">Username</td><td class="row1"><input type="text" name="username" size="20"/></td></tr>
		<tr><td class="rowhead">Password</td><td class="row1"><input type="password" name="password" size="20"/></td></tr>
		<tr><td colspan="2" class="colhead" align="center"><input type="submit" value="Login"/></td></tr>
	</table>
	<?=($_GET['returnto']?"<input type='hidden' name='returnto' value='".htmlspecialchars($_GET['returnto'])."'/>":"")?>
</form>
<?php
stdfoot();
?>