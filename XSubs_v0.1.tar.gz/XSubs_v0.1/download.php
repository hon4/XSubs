<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

$id=(int)$_GET['id'];
$res=sql_query("SELECT filename FROM subtitles WHERE id=".sqlesc($id));
if(mysql_num_rows($res)){
	$row=mysql_fetch_assoc($res);
	
	sql_query("UPDATE subtitles SET dls=dls+1 WHERE id=$id");
	
	$data=file_get_contents("subs/$id.gz");
	$name=$row['filename'].".gz";
	header('Content-Disposition: attachment; filename="'.$name.'"');

    header('Content-Length: '.strlen($data)); 
    
	header("Content-Type: application/gzip");

	print $data; 
}else{
	echo "Bad ID";
}
?>