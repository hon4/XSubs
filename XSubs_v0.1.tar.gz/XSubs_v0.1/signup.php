<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

function validusername($username){
	if($username=="")
		return false;

	//The following characters are allowed in user names
	$allowedchars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	for($i=0;$i<strlen($username);++$i)
		if(strpos($allowedchars,$username[$i])===false)
			return false;

	return true;
}

stdhead("Signup");

if($_POST['takesignup']){
	if(!$_POST['username']||!$_POST['password']||!$_POST['passagain']||!$_POST['email']){
		stderr("Please fill all fields.");
	}else{
		$a=(@mysql_fetch_row(sql_query("SELECT COUNT(*) FROM users WHERE email=".sqlesc($_POST['email']))));
		if($a[0]!=0){
			stderr("The e-mail address $_POST[email] is already in use.");
		}else{
			if(strlen($_POST['username'])>12||!validusername($_POST['username'])){
				stderr("Invalid username format. Allowed chars [a-z],[A-Z],[0-9]. Max 12 chars.");
			}else{
				if($_POST['password']===$_POST['passagain']){
					$secret=mksecret();
					if(!$CONF['SIGNUPMAIL']){
						$status='confirmed';
					}else{
						$status='pending';
					}
					$ret=sql_query("INSERT INTO users (username,password,secret,email,status) VALUES (".sqlesc($_POST['username']).",".sqlesc(md5($_POST['password'])).",".sqlesc($secret).",".sqlesc($_POST['email']).",'".$status."')");
					if(!$ret){
						if(mysql_errno()==1062){
							stderr("Username already exists!");
						}else{
							stderr("Unable to insert user.");
						}
					}else{
						$id=mysql_insert_id();
						if($CONF['SIGNUPMAIL']){
							$psecret=md5($secret);
							$body=<<<EOD
You have requested a new user account on $CONF[SITENAME] and you have
specified this address ($_POST[email]) as user contact.

If you did not do this, please ignore this email. The person who entered your
email address had the IP address {$_SERVER["REMOTE_ADDR"]}. Please do not reply.

To confirm your user registration, you have to follow this link:

$CONF[SITEURL]/confirm.php?id=$id&secret=$psecret

After you do this, you will be able to use your new account. If you fail to
do this, you account will be deleted within a few days. We urge you to read
the RULES and FAQ before you start using $CONF[SITENAME].
EOD;
							@mail($_POST['email'],"$CONF[SITENAME] user registration confirmation",$body,"From: $CONF[SITEEMAIL]","-f$CONF[SITEEMAIL]") or stderr("Unable to send confirm email. Please contact an administrator.");
							stderr("A confirmation email has been sent to the address you specified (".htmlspecialchars($_POST['email']).").<br/>You need to read and respond to this email before you can use your account.<br/>If you don't do this, the new account will be deleted automatically after a few days.","Signup successful!");
						}else{
							stderr("Your account has been successfully created.<br/>Click <a href='login.php'>here</a> to login.","Signup successful!");
						}
						stdfoot();
						die();//Dont show signup again.
					}
				}else{
					stderr("Passwords are not the same.");
				}
			}
		}
	}
}
?>
<form method="post">
	<table class="coltable" align="center">
		<input type="hidden" name="takesignup" value="1"/>
		<tr><td width="1" class="rowhead">Username</td><td class="row1"><input type="text" name="username" size="20"/></td></tr>
		<tr><td class="rowhead">Password</td><td class="row1"><input type="password" name="password" size="20"/></td></tr>
		<tr><td class="rowhead">Password again</td><td class="row1"><input type="password" name="passagain" size="20"/></td></tr>
		<tr><td class="rowhead">Email</td><td class="row1"><input type="text" name="email" size="20"/></td></tr>
		<tr><td colspan="2" class="colhead" align="center"><input type="submit" value="Sign up! (PRESS ONLY ONCE)"/></td></tr>
	</table>
</form>
<?php
stdfoot();
?>