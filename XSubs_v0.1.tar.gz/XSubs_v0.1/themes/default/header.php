<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?=$t?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="stylesheet" type="text/css" href="themes/default/style.css">
	</head>
	<body>
		<div id="page">
			<div id="header"><div id="stats"><?=($CURUSER?'<a href="logout.php">Logout</a> | <a href="subtitles.php?user='.$CURUSER['username'].'"><b><font color="gold">'.$CURUSER['username'].'</font></b></a>':'<a href="login.php">Login</a> | <a href="signup.php">Signup</a>')?></div><a href="index.php"><img id="logo" src="pic/logo2.png" alt="<?=$CONF['SITENAME']?>"/></a></div>
			<div id="nav"><a href="index.php">Home</a><a href="subtitles.php">Subtitles</a><a href="upload.php">Upload</a></div>
			<table id="content">
				<tr><td class="col">