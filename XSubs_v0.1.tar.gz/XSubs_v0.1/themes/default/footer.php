				</td>
				<td class="col" width="22%"><?php rightblocks()?></td></tr>
			</table>
			<div id="footer">XSubs v<?=XSubsVER?> by <a href="//hon-code.blogspot.com" targer="_blank">hon</a> - Style by <a href="//hon-code.blogspot.com" targer="_blank">hon</a> - Script Execution: <?=number_format(microtime(true)-$GLOBALS['tstart'],6)?> sec.</div>
		</div>
	</body>
</html>