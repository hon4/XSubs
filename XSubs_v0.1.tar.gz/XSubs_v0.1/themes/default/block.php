<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
function begin_frame($t=""){
	echo "<table class='frame'><tr><td class='head'><div>$t</div></td></tr><tr><td class='content'>";
}
function end_frame(){
	echo "</td></tr></table>";
}
function begin_block($t=""){
	echo "<table class='block'><tr><td class='head'><div>$t</div></td></tr><tr><td class='content'>";
}
function end_block(){
	echo "</td></tr></table>";
}
?>