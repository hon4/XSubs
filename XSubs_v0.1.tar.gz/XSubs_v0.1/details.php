<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
require_once("backend/functions.php");
dbconn();

stdhead("Subtitle details");
$id=(int)$_GET['id'];
$res=sql_query("SELECT * FROM subtitles WHERE id=".sqlesc($id));
if(mysql_num_rows($res)){
	$row=mysql_fetch_assoc($res);
	begin_frame(htmlspecialchars($row['name']));
	echo "<table class='coltable' width='50%' align='center'><tr><td class='rowhead' width='1'>Name</td><td class='row1'>$row[name]</td></tr>
	<tr><td class='rowhead'>Language</td><td class='row1'>".$CONF['LANG'][$row['lang']]['n']."</td></tr>
	<tr><td class='rowhead'>Upped by</td><td class='row1'>".get_user_username($row['owner'])."</td></tr>
	<tr><td class='rowhead'>Added</td><td class='row1'>$row[added]</td></tr>
	<tr><td class='rowhead'>Downloaded</td><td class='row1'>$row[dls] times</td></tr>
	<tr><td class='rowhead'>Description</td><td class='row1'><pre>".htmlspecialchars($row['descr'])."</pre></td></tr>
	<tr><td colspan='2' class='colhead' align='center'><a href='download.php?id=$id' class='btn'>Download</a></td></tr>
	</table>";
	end_frame();
}else{
	echo "Bad ID";
}
stdfoot();
?>