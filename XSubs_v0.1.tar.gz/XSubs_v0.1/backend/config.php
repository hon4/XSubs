<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
define("XSubsVER","0.1");

$CONF['SITENAME']="XSubs";
$CONF['SITEURL']="http://localhost";
$CONF['SITEEMAIL']="info@localhost";

$CONF['LANG']['0']['n']="Unknown";
$CONF['LANG']['0']['i']="na.gif";
$CONF['LANG']['1']['n']="English";
$CONF['LANG']['1']['i']="en.gif";
$CONF['LANGCOUNT']=1;

$CONF['SIGNUPMAIL']=1;

$MYSQL['HOST']="localhost";
$MYSQL['USER']="root";
$MYSQL['PASS']="root";
$MYSQL['NAME']="xsubs";
?>