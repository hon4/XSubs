<?php
# ╔══════════════════╗
# ║ XSubs v0.1       ║
# ╚══════════════════╝
# │ LastChangedDate: 2024-01-14 23:59:59 +0000 (Sun, 14 Jan 2024) $
# │ LastChangedBy: hon $
# │ hon-code.blogspot.com
# │ honcode.blogspot.com
# └──────────────────>
error_reporting(E_ALL^E_NOTICE);
$tstart=microtime(true);
require_once("backend/config.php");

function dbconn(){
	GLOBAL $MYSQL;
	@mysql_connect($MYSQL['HOST'],$MYSQL['USER'],$MYSQL['PASS']) or die("mysql_connect: ".mysql_error());
	@mysql_select_db($MYSQL['NAME']) or die("mysql_select_db: ".mysql_error());
	@mysql_set_charset("utf8") or die("mysql_select_db: ".mysql_error());
	unset($GLOBALS['MYSQL']); //For security
	userlogin();
}

function stdhead($t=0){
	GLOBAL $CONF,$CURUSER;
	if($t)
		$t="$CONF[SITENAME] : $t";
	else
		$t=$CONF['SITENAME'];
	require_once("themes/default/block.php");
	require_once("themes/default/header.php");
}
function stdfoot(){
	GLOBAL $CURUSER;
	require_once("themes/default/footer.php");
}
function rightblocks(){
	begin_block("Search");
	?>
<form method="get" action="subtitles.php" style="text-align:right">
	<input type="text" name="search" style="width:95%">
	<input type="submit" value="Search">
</form>
	<?php
	end_block();
}
function sql_query($q){
	return @mysql_query($q);
}
function sqlesc($i){
	return "'".mysql_real_escape_string($i)."'";
}
function get_user_username($id){
	$res=sql_query("SELECT username FROM users WHERE id=".sqlesc($id));
	$u=mysql_fetch_array($res);
	return $u[0];
}
function langimg($i){
	GLOBAL $CONF;
	return '<img src="pic/lang/'.$CONF['LANG'][$i]['i'].'" alt="'.$CONF['LANG'][$i]['n'].'"/>';
}
function langlist(){
	GLOBAL $CONF;
	for($i=1;$i<=$CONF['LANGCOUNT'];$i++){
		$l[$i]['n']=$CONF['LANG'][$i]['n'];
		$l[$i]['i']=$i;
	}
	return $l;
}
function stderr($s,$t="Error"){
	echo "<table class='stderr' align='center'>
    <tbody><tr><td><h2>$t</h2></td></tr>
    <tr><td class='embedded'>$s</td></tr>
</tbody></table>";
}
function get_datetime(){
	return date("Y-m-d H:i:s");
}
function logincookie($id,$pass,$secret){
	setcookie("uid",$id,0x7fffffff,"/");
	setcookie("pass",md5($secret.$pass.$secret),0x7fffffff,"/");
}
function logoutcookie(){
	setcookie("uid",NULL,time(),"/");
	setcookie("pass",NULL,time(),"/");
}
function mksecret($len=20){
	$chars=array_merge(range(0,9),range("A","Z"),range("a","z"));
	shuffle($chars);
	$x=count($chars)-1;
	for($i=1;$i<=$len;$i++)
		$str.=$chars[mt_rand(0,$x)];
	return $str;
}
function userlogin(){
	if($_COOKIE["uid"]&&$_COOKIE["pass"]){
		$res=sql_query("SELECT * FROM users WHERE id=".sqlesc($_COOKIE["uid"]));
		if($res){
			$row=mysql_fetch_assoc($res);
			if(md5($row['secret'].$row['password'].$row['secret'])===$_COOKIE["pass"]){
				$GLOBALS['CURUSER']=$row;
			}
		}
	}
}
function loggedinonly(){
	GLOBAL $CURUSER;
	if(!$CURUSER){
		header("Location: login.php?returnto=".urlencode($_SERVER['REQUEST_URI']));
	}
}
function subtitletable($res){
	echo "<table class='coltable' width='100%'><tr class='colhead'><td width=1></td><td>Name</td><td width=1><nobr>Upped by</nobr></td><td width=1>Added</td><td width=1></td></tr>";
	while($row=mysql_fetch_assoc($res)){
		echo "<tr class='row1'><td>".langimg($row['lang'])."</td><td><a href='details.php?id=$row[id]'>$row[name]</a></td><td><a href='subtitles.php?userid=$row[owner]'>".get_user_username($row['owner'])."</a></td><td><nobr>$row[added]</nobr></td><td><a href='details.php?id=$row[id]'><img src='pic/dl.gif' alt='Download'/></a></td></tr>";
	}
	echo "</table>";
}
function pager($rpp,$count,$href,$opts=array()){
	$pages=ceil($count/$rpp);

	if(!$opts["lastpagedefault"])
		$pagedefault=0;
	else{
		$pagedefault=floor(($count-1)/$rpp);
		if($pagedefault<0)
			$pagedefault=0;
	}

	if(isset($_GET["page"])){
		$page=0+$_GET["page"];
		if($page<0)
			$page=$pagedefault;
	}else
		$page=$pagedefault;

    $pager="";

	$mp=$pages-1;
	$as="<b>&lt;&lt;&nbsp;Prev</b>";
	if($page>=1){
		$pager.="<a href=\"{$href}page=".($page-1)."\">";
		$pager.=$as;
		$pager.="</a>";
	}else
		$pager.=$as;
	$pager.="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	$as="<b>Next&nbsp;&gt;&gt;</b>";
	if($page<$mp&&$mp>=0){
		$pager.="<a href=\"{$href}page=".($page+1)."\">";
		$pager.=$as;
		$pager.="</a>";
	}else
		$pager.=$as;

	if($count){
		$pagerarr=array();
		$dotted=0;
		$dotspace=3;
		$dotend=$pages-$dotspace;
		$curdotend=$page-$dotspace;
		$curdotstart=$page+$dotspace;
		for($i=0;$i<$pages;$i++){
			if(($i>=$dotspace&&$i<=$curdotend)||($i>=$curdotstart&&$i<$dotend)){
				if(!$dotted)
					$pagerarr[]="...";
				$dotted=1;
				continue;
			}
			$dotted=0;
			$start=$i*$rpp+1;
			$end=$start+$rpp-1;
			if($end>$count)
				$end=$count;
			$text="$start&nbsp;-&nbsp;$end";
			if($i!=$page)
				$pagerarr[]="<a href=\"{$href}page=$i\"><b>$text</b></a>";
			else
				$pagerarr[]="<b>$text</b>";
		}
		$pagerstr=join(" | ",$pagerarr);
		$pagertop="<p align=\"center\">$pager<br/>$pagerstr</p>\n";
		$pagerbottom="<p align=\"center\">$pagerstr<br/>$pager</p>\n";
	}else{
		$pagertop="<p align=\"center\">$pager</p>\n";
		$pagerbottom=$pagertop;
    }

	$start=$page*$rpp;

	return array($pagertop,$pagerbottom,"LIMIT $start,$rpp");
}
?>